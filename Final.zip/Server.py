from flask import Flask, render_template, request, session, redirect, url_for
from flask_socketio import join_room, leave_room, send, SocketIO
import random 
from string import ascii_uppercase

# Setup Application สร้างเว็บขึ้นมา
#เพื่อให้ Flask รู้ว่าจะค้นหาและเรียกใช้ไฟล์และเทมเพลตต่าง ๆ ในส่วนของแอปพลิเคชันได้อย่างถูกต้อง
app = Flask(__name__)
#SECRET_KEY เป็นคีย์สำหรับการเข้ารหัสคุ้กกี้หรือข้อมูลที่เก็บในเซสชัน เพื่อเพิ่มความปลอดภัยในการใช้งาน
app.config["SECRET_KEY"] = "ADMIN123"
#สร้างอ็อบเจกต์ของเซิร์ฟเวอร์ WebSocket ซึ่งเราจะใช้เซิร์ฟเวอร์ WebSocket เพื่อการสื่อสารแบบ real-time ระหว่างเซิร์ฟเวอร์และ client
socketio = SocketIO(app)

# เก็บเลขห้องเอาไว้
rooms = {}

# generate รหัสห้อง โดยสุ่ม
def generate_room(roomnum):
    while True:
        code=""
        for _ in range(roomnum):
            code += random.choice(ascii_uppercase)
        if code not in rooms:
            break
    return code

# Redirect ไป home
#หากเป็น GET: จะแสดงหน้า HTML(เปิดเว็บ)(return redirect(url_for("room")))
#GET: เมื่อผู้ใช้เปิด URL /
#หากเป็น POST: จะดำเนินการตามเงื่อนไขต่าง ๆ 
#POST: เมื่อผู้ใช้ส่งแบบฟอร์มบนหน้าแรก
@app.route("/",methods=["POST","GET"])#ถ้าเปิดลิ้ง(GET)แล้วจะทำฟั่งชั่น แต่ถ้ามีการPOSTจากหน้านั้นก็จะในฟังชั่นเช่นกัน
def home():
    # ล้าง homepage ใหม่
    session.clear()

    # การรับค่าจากผู้ใช้
    if request.method == "POST":
        
        name = request.form.get("name")#name="name" ก็ดึงค่าจาก value="{{ name }}"มั้ง
        code = request.form.get("code")
        join = request.form.get("join",False) # หากไม่พบค่า "join" ในฟอร์ม ค่า join จะเป็น False
        create = request.form.get("create",False)
        
        # เช็ค error
        #render_template ส่งข้อมูลไปเว็บนั้น
        if not name:
            return render_template("home.html", error="Please enter name.",code=code,name=name)#{{ name }}เหตุผลที่ต้องประกาศตัวแปรเพราะจะได้ส่งค่าไปใส่
        if join != False and not code:#กดjoin ไม่ใส่โค้ดนั้นเอง
            return render_template("home.html", error="Please enter room code.",code=code,name=name)
        
        # สร้างห้อง + เก็บข้อมูลที่เกิดภายในห้อง
        room = code
        # สร้างห้อง
        if create != False:
            room = generate_room(5)#5ตัวอักษร
            # Store Data
            rooms[room] = {"members": 0, "messages":[]}
        # เข้าห้อง
        elif code not in rooms:
            return render_template("home.html",error="Room does not exist",code=code,name=name)
        
        # เก็บค่าของผู้ใช้ชั่วคราว เอาไปใช้หน้าต่อไป
        session["room"] = room
        session["name"] = name

        return redirect(url_for("room"))#ไปยังฟังชั่นroom

    return render_template("home.html")

# Redirect ไป room
@app.route("/room")
def room():
    room = session.get("room")
    if room is None or session.get("name") is None or room not in rooms:
        return redirect(url_for("home"))#ไปยังเส้นทางนั้น(หน้านั้นหรือฟังชั่นนั้นก็ได้) อันนี้ให้ไปยังฟังชั่นโฮม
    return render_template("room.html", code=room, messages=rooms[room]["messages"])

# การเชื่อมห้อง
@socketio.on("connect")#เริ่มทำงาน  เมื่อไคลเอนต์ เชื่อมต่อกับเซิร์ฟเวอร์
def connect():
#   print("1")
  room = session.get("room")
  name = session.get("name")
  if not room or not name:
    return
  if room not in rooms:
    leave_room(room)#ถึงเหลือ 0 ก็ไม่ลบ ที่ลบแค่ตัวแปร
    return
  join_room(room)#เพิ่มคนนั้นเข้าห้องหากยังไม่มีจะสร้าง
  send({"name": name, "message": "has entered the room"}, to=room)
  rooms[room]["members"] += 1
  print(f"{name} joined room {room}")

# การออกห้อง
@socketio.on("disconnect")
def disconnect():
    room = session.get("room")
    name = session.get("name")
    leave_room(room)

    if room in rooms:
        rooms[room]["members"] -= 1
        if rooms[room]["members"] <= 0:
            del rooms[room]
    send({"name": name, "message": "has left the room"}, to=room)
    print(f"{name} lefted room {room}")

# การส่งข้อความ
@socketio.on("message")#รับข้อมูลทั้งหมดที่ถูกส่งมาในชนิดของ "message"
def message(data):
    room = session.get("room")
    if room not in rooms:
        return 
    
    content = {
        "name": session.get("name"),
        "message": data["data"]
    }
    send(content, to=room)
    rooms[room]["messages"].append(content)
    print(f"{session.get('name')} said: {data['data']}")

if __name__ == "__main__":
    #ป้องกันการ import ป็นโค้ดที่ใช้ใน Python เพื่อทำให้โค้ดที่อยู่ในบล็อกนั้นถูกเรียกใช้งานเฉพาะเมื่อไฟล์ Python ถูกเรียกโดยตรงโดยไม่ได้ถูก import 
    #เมื่อรันโค้ดโดยตรง __name__ จะมีค่าเป็น "__main__"
    socketio.run(app,host='0.0.0.0',debug=True)

'''
ในบล็อกนี้ socketio.run(app, host='0.0.0.0', debug=True) ใช้เพื่อรันแอพพลิเคชัน Flask ของเรา โดย socketio.run() จะเป็นเมทอดที่ใช้ใน Flask-SocketIO เพื่อรันแอพพลิเคชัน Flask ของเราพร้อมกับการใช้งาน Socket.IO

app คือตัวแปรที่เก็บ Flask application ที่เราสร้างขึ้น
host='0.0.0.0' ระบุให้เซิร์ฟเวอร์เปิดอยู่ที่ IP address 0.0.0.0 ซึ่งหมายถึงให้เปิดให้สามารถเข้าถึงได้ทุก IP address บนเครื่องเซิร์ฟเวอร์
debug=True เป็นการเปิดโหมด debug ซึ่งจะแสดงข้อผิดพลาดและข้อมูลเกี่ยวกับการทำงานของแอพพลิเคชันใน console log ที่สำคัญสำหรับการพัฒนาและทดสอบโปรแกรม

แอปพลิเคชัน Socket.IO ควรเป็นสิ่งสุดท้ายที่รัน
เพราะว่าแอปพลิเคชัน Socket.IO จะรันจนกว่าจะได้รับการหยุด
โค้ดอื่น ๆ จะไม่สามารถรันได้
'''